<?php
if(count($_COOKIE) > 0) {
	echo "Cookies activados.";
} else {
	echo "Cookies não activados.";
}
?>
</body>
</html>