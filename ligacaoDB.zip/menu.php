<?php
echo '<a href="#">Home</a> |
<a href="#">HTML Tutorial</a> |
<a href="#">CSS Tutorial</a> |
<a href="#">JavScript Tutorial</a> |
<a href="#">PHP Tutorial</a>';
?>