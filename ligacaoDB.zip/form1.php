<p>Método POST</p>
<form action = "cliente.php" method="post">
Nome: <input type="text" name="nome"><br>
E-mail: <input type="text" name="email"><br>
<input type="submit">
</form>
<p>Método GET</p>
<form action="cliente_get.php" method="get">
Nome: <input type="text" name="nome"><br />
E-mail: <input type="text" name="email"><br />
<input type="submit">
</form>
