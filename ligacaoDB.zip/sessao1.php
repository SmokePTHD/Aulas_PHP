<?php
session_start();
$_SESSION["favcor"] = "verde";
$_SESSION["favanimal"] = "gato";
echo "Variáveis de sessão definidas.";
?>