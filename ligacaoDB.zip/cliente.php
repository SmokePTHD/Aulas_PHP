Bem-vindo <?php echo $_POST["nome"]; ?><br />
O seu e-mail é: <?php echo $_POST["email"]; ?>