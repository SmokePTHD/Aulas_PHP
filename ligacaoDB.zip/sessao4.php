<?php
session_start();
$_SESSION["favcor"] = "amarelo";
print_r($_SESSION);
?>