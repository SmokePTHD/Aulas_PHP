<?php
    $ficheiro = fopen("webdicionario.txt")
?>