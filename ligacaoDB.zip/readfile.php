<?php
echo readfile("webdicionario.txt");
?>