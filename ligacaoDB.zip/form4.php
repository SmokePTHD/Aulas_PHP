<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <form action="upload.php" method="post" enctype="multipart/form-data">
        Selecione a imagem para carregar.
        <input type="file" name="imgrupload" id="imgrupload">
        <input type="submit" value="Carregar imagem" name="submit">
    </form>
</body>
</html>