<?php //login.php Este é o ficheiro de login, acedendo a localhost e à base de dados publicacoes, incluindo o username e password que têm privilégios de administração
	$hn = 'localhost';
	$db = 'publicacoes';
	$un = 'goncalo123';
	$pw = 'password1234';
?>