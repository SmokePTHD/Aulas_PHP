<html>
 <meta charset="UTF-8">
<body>
Bem-vindo <?php echo $_POST["nome"]; ?><br />
O seu e-mail é: <?php echo $_POST["email"]; ?><br />
O seu website é: <?php echo $_POST["website"]; ?><br />
O seu género é: <?php echo $_POST["genero"]; ?><br />
O seu comentário foi: <?php echo $_POST["coment"]; ?><br />
</body>
</html>