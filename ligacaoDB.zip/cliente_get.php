Bem-vindo <?php echo $_GET["nome"]; ?><br />
O seu e-mail é: <?php echo $_GET["email"]; ?>